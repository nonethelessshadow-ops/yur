package app.chessvision.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var rootView: View? = null
    private var webView: WebView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val n = notification()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        if (rootView == null) show()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("overlay", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).apply { action = "STOP" }, PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "overlay")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("ChessVision overlay is running")
            .addAction(android.R.drawable.ic_delete, "Stop", stop)
            .build()
    }

    private fun show() {
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val scr = resources.displayMetrics
        val d = scr.density
        fun dp(v: Int) = (v * d).toInt()
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val fNoFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE

        val lp = WindowManager.LayoutParams(
            minOf(dp(340), scr.widthPixels - dp(16)),
            minOf(dp(560), scr.heightPixels - dp(120)),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            fNoFocus or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(72) }

        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            setBackgroundColor(0xFF121214.toInt())
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    view.evaluateJavascript(
                        "var f=document.querySelector('#mini .pri');if(f)f.style.display='none';", null
                    )
                }
            }
            loadUrl("file:///android_asset/chessvision.html")
        }
        webView = web

        val grip = TextView(this).apply {
            text = "◢"; textSize = 18f; setTextColor(0x99FFFFFF.toInt()); gravity = Gravity.CENTER
        }
        val body = FrameLayout(this).apply {
            addView(web, FrameLayout.LayoutParams(mp, mp))
            addView(grip, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.BOTTOM or Gravity.END))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF24242A.toInt())
        }
        header.addView(
            TextView(this).apply {
                text = "  ♟ ChessVision"; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER_VERTICAL
            },
            LinearLayout.LayoutParams(0, mp, 1f)
        )

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xFF121214.toInt()); cornerRadius = dp(14).toFloat(); setStroke(dp(1), 0xFF10B981.toInt())
            }
            clipToOutline = true
            addView(header, LinearLayout.LayoutParams(mp, dp(38)))
            addView(body, LinearLayout.LayoutParams(mp, 0, 1f))
        }
        rootView = root

        fun btn(t: String, onClick: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setPadding(dp(12), 0, dp(12), 0); setOnClickListener { onClick() }
        }

        var kb = false
        header.addView(btn("⌨") {
            kb = !kb
            lp.flags = if (kb) lp.flags and fNoFocus.inv() else lp.flags or fNoFocus
            manager.updateViewLayout(root, lp)
            if (kb) web.requestFocus()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, mp))

        var mini = false
        var fullW = lp.width
        var fullH = lp.height
        header.addView(btn("—") {
            mini = !mini
            if (mini) {
                fullW = lp.width; fullH = lp.height
                body.visibility = View.GONE
                lp.width = dp(190); lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            } else {
                body.visibility = View.VISIBLE
                lp.width = fullW; lp.height = fullH
            }
            manager.updateViewLayout(root, lp)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, mp))

        header.addView(btn("✕") { stopSelf() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, mp))

        // drag by the header
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        header.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (sx + (e.rawX - tx)).toInt().coerceIn(0, scr.widthPixels - dp(60))
                    lp.y = (sy + (e.rawY - ty)).toInt().coerceIn(0, scr.heightPixels - dp(60))
                    manager.updateViewLayout(root, lp)
                }
            }
            true
        }

        // resize with the bottom-right grip
        var sw = 0; var sh = 0; var gx = 0f; var gy = 0f
        grip.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sw = lp.width; sh = lp.height; gx = e.rawX; gy = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.width = (sw + (e.rawX - gx)).toInt().coerceIn(dp(240), scr.widthPixels)
                    lp.height = (sh + (e.rawY - gy)).toInt().coerceIn(dp(240), scr.heightPixels)
                    manager.updateViewLayout(root, lp)
                }
            }
            true
        }

        manager.addView(root, lp)
    }

    override fun onDestroy() {
        rootView?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        webView?.destroy()
        rootView = null; webView = null
        super.onDestroy()
    }
}
