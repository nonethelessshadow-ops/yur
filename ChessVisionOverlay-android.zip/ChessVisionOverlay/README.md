# ChessVision Overlay (Android)

Floating, draggable, resizable ChessVision window that stays on top of other apps.

Build: open this folder in Android Studio (JDK 17), let Gradle sync, then Run on your phone
(or Build > Build APK(s) and install it). First launch: tap Start overlay, allow
"Display over other apps", tap Start again.

In the window: drag the title bar, resize with the bottom-right corner, - minimize,
the keyboard button toggles typing (needed for a FEN), X closes. Stop also works from the notification.
The app is app/src/main/assets/chessvision.html - edit it to change the board.
